/* Name: Gabriel Hernandez
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/

package MyAllExecuterServlets;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class MyDataReader {

    public MyDataReader() {
    }
    
   public ArrayList<String> getData()
    {
        JOptionPane.showMessageDialog(null, "jjjjjjjjjjjjjjjjjjjjjjjj");
        
        ArrayList<String> list = new ArrayList<>();
    
          try {
            File myObj = new File("credentials.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
              String data = myReader.nextLine();
              list.add(data);
              
            }
            myReader.close();
          } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }
        
     return list;
    }    
    
}
