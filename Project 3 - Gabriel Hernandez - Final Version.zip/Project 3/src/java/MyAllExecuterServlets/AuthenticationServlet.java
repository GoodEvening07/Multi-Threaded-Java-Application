/* Name: Gabriel Hernandez
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/

package MyAllExecuterServlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

@WebServlet(name = "AuthenticationServlet", urlPatterns = {"/AuthenticationServlet"})
public class AuthenticationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
                response.setContentType("text/html;charset=UTF-8");
                String userName = request.getParameter("username");
                String passWord = request.getParameter("pass");
                String filePath = "credentials.txt";
                ArrayList<String> dataList= new ArrayList<>();
                InputStream inputStream = getServletContext().getResourceAsStream(filePath);

                if (inputStream != null) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
                        String currentLine;
                        while ((currentLine = reader.readLine()) != null) {
                        dataList.add(currentLine);  
                    }
                    }
                } 
                
                boolean isFound=false;
                for(int currentIndex=0;currentIndex<dataList.size();currentIndex++)
                {
                    String un = dataList.get(currentIndex).split(",")[0];
                    String upass = dataList.get(currentIndex).split(",")[1];
                    
                        if(userName.equals(un) && upass.equals(passWord))
                        {
                            isFound=true;
                                if(un.charAt(0)=='r')
                                {
                                
                                request.setAttribute("mesg", userName);
                                RequestDispatcher dispatcher = request.getRequestDispatcher("/rootHome.jsp");
                                dispatcher.forward(request, response);   
                                }
                                else if(un.charAt(0)=='c')
                                {
                                request.setAttribute("mesg", userName);
                                RequestDispatcher dispatcher = request.getRequestDispatcher("/clientHome.jsp");
                                dispatcher.forward(request, response);
                                }
                                else if(un.charAt(0)=='d')
                                {
                                request.setAttribute("mesg", userName);
                                RequestDispatcher dispatcher = request.getRequestDispatcher("/dataEntryHome.jsp");
                                dispatcher.forward(request, response);
                                }
                                else if(un.charAt(0)=='a')
                                {
                                    request.setAttribute("mesg", userName);
                                    RequestDispatcher dispatcher = request.getRequestDispatcher("/accountantHome.jsp");
                                    dispatcher.forward(request, response);
                                }
                        }
                }
                
                if(!isFound)
                {
                System.out.println("User = "+userName);
                System.out.println("Pass= "+passWord);
                System.out.println(request.getParameter("mt"));
                request.setAttribute("mesg", userName);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/errorpage.html");
                dispatcher.forward(request, response);
                }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
