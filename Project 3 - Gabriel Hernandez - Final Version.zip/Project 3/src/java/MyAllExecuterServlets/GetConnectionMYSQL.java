/* Name: Gabriel Hernandez
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/

package MyAllExecuterServlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JLabel;
import com.mysql.cj.jdbc.MysqlDataSource;


public class GetConnectionMYSQL {

    public  Connection connectionClientConnection() {
        try {
            String connURL = "jdbc:mysql://localhost:3306/project3";
           
            String hostName="client";
            String hostPass = "client";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(connURL, hostName, hostPass);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            return null; 
        }
    }

     public  Connection connectionDataEntry() {
        try {
            String connURL = "jdbc:mysql://localhost:3306/project3";
           
            String hostName="dataentryuser";
            String hostPass = "dataentryuser";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(connURL, hostName, hostPass);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            return null; 
        }
    }

     public  Connection connectionAccountant() {
        try {
            String connURL = "jdbc:mysql://localhost:3306/project3";
           
            String hostName="accountant";
            String hostPass = "theaccountant";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(connURL, hostName, hostPass);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            return null; 
        }
    }

     public  Connection connectionRoot() {
        try {
            String connURL = "jdbc:mysql://localhost:3306/project4";
           
            String hostName="root";
            String hostPass = "rootMac1$";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(connURL, hostName, hostPass);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            
            return null; 
        }
    }
    
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

